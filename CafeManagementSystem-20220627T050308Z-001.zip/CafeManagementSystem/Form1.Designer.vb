﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.newToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.rtfReceipt = New System.Windows.Forms.RichTextBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtQueen = New System.Windows.Forms.TextBox()
        Me.txtCoffeCake = New System.Windows.Forms.TextBox()
        Me.chkQueen = New System.Windows.Forms.CheckBox()
        Me.txtRed = New System.Windows.Forms.TextBox()
        Me.chkCarlton = New System.Windows.Forms.CheckBox()
        Me.txtBlackForest = New System.Windows.Forms.TextBox()
        Me.chkKilburn = New System.Windows.Forms.CheckBox()
        Me.txtBostom = New System.Windows.Forms.TextBox()
        Me.chkLagos = New System.Windows.Forms.CheckBox()
        Me.txtLagos = New System.Windows.Forms.TextBox()
        Me.chkBostom = New System.Windows.Forms.CheckBox()
        Me.txtKilburn = New System.Windows.Forms.TextBox()
        Me.chkBlackForest = New System.Windows.Forms.CheckBox()
        Me.txtCharlton = New System.Windows.Forms.TextBox()
        Me.chkRed = New System.Windows.Forms.CheckBox()
        Me.chkCoffeCake = New System.Windows.Forms.CheckBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.btnReceipt = New System.Windows.Forms.Button()
        Me.TotalButton = New System.Windows.Forms.Button()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtLatte = New System.Windows.Forms.TextBox()
        Me.txtEspresso = New System.Windows.Forms.TextBox()
        Me.txtIceLatte = New System.Windows.Forms.TextBox()
        Me.txtCappucino = New System.Windows.Forms.TextBox()
        Me.txtVales = New System.Windows.Forms.TextBox()
        Me.txtAfrican = New System.Windows.Forms.TextBox()
        Me.txtAmerican = New System.Windows.Forms.TextBox()
        Me.txtIced = New System.Windows.Forms.TextBox()
        Me.chkLatte = New System.Windows.Forms.CheckBox()
        Me.chkEspresso = New System.Windows.Forms.CheckBox()
        Me.chkIceLatte = New System.Windows.Forms.CheckBox()
        Me.chkCappucino = New System.Windows.Forms.CheckBox()
        Me.chkVales = New System.Windows.Forms.CheckBox()
        Me.chkAfrican = New System.Windows.Forms.CheckBox()
        Me.chkAmerican = New System.Windows.Forms.CheckBox()
        Me.chkIced = New System.Windows.Forms.CheckBox()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.lblTotal = New System.Windows.Forms.TextBox()
        Me.lbl1tax = New System.Windows.Forms.Label()
        Me.lblSubtotal = New System.Windows.Forms.TextBox()
        Me.lbl1Subtotal = New System.Windows.Forms.Label()
        Me.lbltax = New System.Windows.Forms.TextBox()
        Me.lbl1Total = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.lblService = New System.Windows.Forms.TextBox()
        Me.lblCostCake = New System.Windows.Forms.TextBox()
        Me.lblCostDrink = New System.Windows.Forms.TextBox()
        Me.lbl1Service = New System.Windows.Forms.Label()
        Me.lbl1CostCake = New System.Windows.Forms.Label()
        Me.lbl1CostDrink = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.PrintDialog1 = New System.Windows.Forms.PrintDialog()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.lblTime = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.ImageList2 = New System.Windows.Forms.ImageList(Me.components)
        Me.ToolStripButton3 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.saveToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.printToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.cutToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.copyToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.pasteToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.helpToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel2.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.ToolStrip1)
        Me.Panel2.Controls.Add(Me.rtfReceipt)
        Me.Panel2.Location = New System.Drawing.Point(968, 129)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(372, 452)
        Me.Panel2.TabIndex = 1
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton3, Me.ToolStripButton2, Me.saveToolStripButton1, Me.printToolStripButton2, Me.newToolStripSeparator1, Me.cutToolStripButton1, Me.copyToolStripButton1, Me.pasteToolStripButton, Me.ToolStripSeparator2, Me.helpToolStripButton1})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(368, 25)
        Me.ToolStrip1.TabIndex = 1
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'newToolStripSeparator1
        '
        Me.newToolStripSeparator1.Name = "newToolStripSeparator1"
        Me.newToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'rtfReceipt
        '
        Me.rtfReceipt.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rtfReceipt.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtfReceipt.Location = New System.Drawing.Point(21, 61)
        Me.rtfReceipt.Name = "rtfReceipt"
        Me.rtfReceipt.Size = New System.Drawing.Size(333, 375)
        Me.rtfReceipt.TabIndex = 0
        Me.rtfReceipt.Text = ""
        '
        'Panel3
        '
        Me.Panel3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel3.Controls.Add(Me.Label3)
        Me.Panel3.Controls.Add(Me.txtQueen)
        Me.Panel3.Controls.Add(Me.txtCoffeCake)
        Me.Panel3.Controls.Add(Me.chkQueen)
        Me.Panel3.Controls.Add(Me.txtRed)
        Me.Panel3.Controls.Add(Me.chkCarlton)
        Me.Panel3.Controls.Add(Me.txtBlackForest)
        Me.Panel3.Controls.Add(Me.chkKilburn)
        Me.Panel3.Controls.Add(Me.txtBostom)
        Me.Panel3.Controls.Add(Me.chkLagos)
        Me.Panel3.Controls.Add(Me.txtLagos)
        Me.Panel3.Controls.Add(Me.chkBostom)
        Me.Panel3.Controls.Add(Me.txtKilburn)
        Me.Panel3.Controls.Add(Me.chkBlackForest)
        Me.Panel3.Controls.Add(Me.txtCharlton)
        Me.Panel3.Controls.Add(Me.chkRed)
        Me.Panel3.Controls.Add(Me.chkCoffeCake)
        Me.Panel3.Location = New System.Drawing.Point(461, 129)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(501, 386)
        Me.Panel3.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe Print", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(209, 26)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(76, 43)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Cake"
        '
        'txtQueen
        '
        Me.txtQueen.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtQueen.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtQueen.Location = New System.Drawing.Point(376, 97)
        Me.txtQueen.Name = "txtQueen"
        Me.txtQueen.Size = New System.Drawing.Size(66, 22)
        Me.txtQueen.TabIndex = 1
        Me.txtQueen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtCoffeCake
        '
        Me.txtCoffeCake.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtCoffeCake.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCoffeCake.Location = New System.Drawing.Point(376, 330)
        Me.txtCoffeCake.Name = "txtCoffeCake"
        Me.txtCoffeCake.Size = New System.Drawing.Size(66, 22)
        Me.txtCoffeCake.TabIndex = 1
        Me.txtCoffeCake.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chkQueen
        '
        Me.chkQueen.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkQueen.AutoSize = True
        Me.chkQueen.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkQueen.Location = New System.Drawing.Point(18, 97)
        Me.chkQueen.Name = "chkQueen"
        Me.chkQueen.Size = New System.Drawing.Size(267, 24)
        Me.chkQueen.TabIndex = 0
        Me.chkQueen.Text = "Queen's Park Chocolate Cake"
        Me.chkQueen.UseVisualStyleBackColor = True
        '
        'txtRed
        '
        Me.txtRed.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtRed.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRed.Location = New System.Drawing.Point(376, 295)
        Me.txtRed.Name = "txtRed"
        Me.txtRed.Size = New System.Drawing.Size(66, 22)
        Me.txtRed.TabIndex = 1
        Me.txtRed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chkCarlton
        '
        Me.chkCarlton.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkCarlton.AutoSize = True
        Me.chkCarlton.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkCarlton.Location = New System.Drawing.Point(18, 133)
        Me.chkCarlton.Name = "chkCarlton"
        Me.chkCarlton.Size = New System.Drawing.Size(258, 24)
        Me.chkCarlton.TabIndex = 0
        Me.chkCarlton.Text = "Charlton Hill Chocolate Cake"
        Me.chkCarlton.UseVisualStyleBackColor = True
        '
        'txtBlackForest
        '
        Me.txtBlackForest.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBlackForest.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBlackForest.Location = New System.Drawing.Point(376, 264)
        Me.txtBlackForest.Name = "txtBlackForest"
        Me.txtBlackForest.Size = New System.Drawing.Size(66, 22)
        Me.txtBlackForest.TabIndex = 1
        Me.txtBlackForest.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chkKilburn
        '
        Me.chkKilburn.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkKilburn.AutoSize = True
        Me.chkKilburn.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkKilburn.Location = New System.Drawing.Point(18, 165)
        Me.chkKilburn.Name = "chkKilburn"
        Me.chkKilburn.Size = New System.Drawing.Size(215, 24)
        Me.chkKilburn.TabIndex = 0
        Me.chkKilburn.Text = "Kilburn Chocolate Cake"
        Me.chkKilburn.UseVisualStyleBackColor = True
        '
        'txtBostom
        '
        Me.txtBostom.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBostom.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBostom.Location = New System.Drawing.Point(376, 231)
        Me.txtBostom.Name = "txtBostom"
        Me.txtBostom.Size = New System.Drawing.Size(66, 22)
        Me.txtBostom.TabIndex = 1
        Me.txtBostom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chkLagos
        '
        Me.chkLagos.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLagos.AutoSize = True
        Me.chkLagos.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkLagos.Location = New System.Drawing.Point(18, 198)
        Me.chkLagos.Name = "chkLagos"
        Me.chkLagos.Size = New System.Drawing.Size(209, 24)
        Me.chkLagos.TabIndex = 0
        Me.chkLagos.Text = "Lagos Chocolate Cake"
        Me.chkLagos.UseVisualStyleBackColor = True
        '
        'txtLagos
        '
        Me.txtLagos.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtLagos.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLagos.Location = New System.Drawing.Point(376, 195)
        Me.txtLagos.Name = "txtLagos"
        Me.txtLagos.Size = New System.Drawing.Size(66, 22)
        Me.txtLagos.TabIndex = 1
        Me.txtLagos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chkBostom
        '
        Me.chkBostom.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkBostom.AutoSize = True
        Me.chkBostom.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkBostom.Location = New System.Drawing.Point(18, 231)
        Me.chkBostom.Name = "chkBostom"
        Me.chkBostom.Size = New System.Drawing.Size(192, 24)
        Me.chkBostom.TabIndex = 0
        Me.chkBostom.Text = "Bostom Cream Cake"
        Me.chkBostom.UseVisualStyleBackColor = True
        '
        'txtKilburn
        '
        Me.txtKilburn.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtKilburn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtKilburn.Location = New System.Drawing.Point(376, 162)
        Me.txtKilburn.Name = "txtKilburn"
        Me.txtKilburn.Size = New System.Drawing.Size(66, 22)
        Me.txtKilburn.TabIndex = 1
        Me.txtKilburn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chkBlackForest
        '
        Me.chkBlackForest.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkBlackForest.AutoSize = True
        Me.chkBlackForest.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkBlackForest.Location = New System.Drawing.Point(18, 266)
        Me.chkBlackForest.Name = "chkBlackForest"
        Me.chkBlackForest.Size = New System.Drawing.Size(175, 24)
        Me.chkBlackForest.TabIndex = 0
        Me.chkBlackForest.Text = "Black Forest Cake"
        Me.chkBlackForest.UseVisualStyleBackColor = True
        '
        'txtCharlton
        '
        Me.txtCharlton.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtCharlton.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCharlton.Location = New System.Drawing.Point(376, 130)
        Me.txtCharlton.Name = "txtCharlton"
        Me.txtCharlton.Size = New System.Drawing.Size(66, 22)
        Me.txtCharlton.TabIndex = 1
        Me.txtCharlton.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chkRed
        '
        Me.chkRed.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkRed.AutoSize = True
        Me.chkRed.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkRed.Location = New System.Drawing.Point(18, 298)
        Me.chkRed.Name = "chkRed"
        Me.chkRed.Size = New System.Drawing.Size(162, 24)
        Me.chkRed.TabIndex = 0
        Me.chkRed.Text = "Red Velvet Cake"
        Me.chkRed.UseVisualStyleBackColor = True
        '
        'chkCoffeCake
        '
        Me.chkCoffeCake.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkCoffeCake.AutoSize = True
        Me.chkCoffeCake.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkCoffeCake.Location = New System.Drawing.Point(18, 333)
        Me.chkCoffeCake.Name = "chkCoffeCake"
        Me.chkCoffeCake.Size = New System.Drawing.Size(118, 24)
        Me.chkCoffeCake.TabIndex = 0
        Me.chkCoffeCake.Text = "Coffe Cake"
        Me.chkCoffeCake.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel4.Controls.Add(Me.Button4)
        Me.Panel4.Controls.Add(Me.Button3)
        Me.Panel4.Controls.Add(Me.btnReceipt)
        Me.Panel4.Controls.Add(Me.TotalButton)
        Me.Panel4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel4.Location = New System.Drawing.Point(970, 587)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(370, 92)
        Me.Panel4.TabIndex = 3
        '
        'Button4
        '
        Me.Button4.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button4.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.Button4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(274, 37)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(84, 35)
        Me.Button4.TabIndex = 0
        Me.Button4.Text = "EXIT"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button3.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.Button3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(193, 37)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 35)
        Me.Button3.TabIndex = 0
        Me.Button3.Text = "Reset"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'btnReceipt
        '
        Me.btnReceipt.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnReceipt.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.btnReceipt.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnReceipt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReceipt.Location = New System.Drawing.Point(101, 37)
        Me.btnReceipt.Name = "btnReceipt"
        Me.btnReceipt.Size = New System.Drawing.Size(86, 35)
        Me.btnReceipt.TabIndex = 0
        Me.btnReceipt.Text = "Receipt"
        Me.btnReceipt.UseVisualStyleBackColor = False
        '
        'TotalButton
        '
        Me.TotalButton.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TotalButton.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.TotalButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TotalButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TotalButton.Location = New System.Drawing.Point(19, 37)
        Me.TotalButton.Name = "TotalButton"
        Me.TotalButton.Size = New System.Drawing.Size(65, 35)
        Me.TotalButton.TabIndex = 0
        Me.TotalButton.Text = "Total"
        Me.TotalButton.UseVisualStyleBackColor = False
        '
        'Panel5
        '
        Me.Panel5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel5.Controls.Add(Me.Label2)
        Me.Panel5.Controls.Add(Me.txtLatte)
        Me.Panel5.Controls.Add(Me.txtEspresso)
        Me.Panel5.Controls.Add(Me.txtIceLatte)
        Me.Panel5.Controls.Add(Me.txtCappucino)
        Me.Panel5.Controls.Add(Me.txtVales)
        Me.Panel5.Controls.Add(Me.txtAfrican)
        Me.Panel5.Controls.Add(Me.txtAmerican)
        Me.Panel5.Controls.Add(Me.txtIced)
        Me.Panel5.Controls.Add(Me.chkLatte)
        Me.Panel5.Controls.Add(Me.chkEspresso)
        Me.Panel5.Controls.Add(Me.chkIceLatte)
        Me.Panel5.Controls.Add(Me.chkCappucino)
        Me.Panel5.Controls.Add(Me.chkVales)
        Me.Panel5.Controls.Add(Me.chkAfrican)
        Me.Panel5.Controls.Add(Me.chkAmerican)
        Me.Panel5.Controls.Add(Me.chkIced)
        Me.Panel5.Location = New System.Drawing.Point(12, 129)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(443, 386)
        Me.Panel5.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe Print", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(159, 26)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 43)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Coffe"
        '
        'txtLatte
        '
        Me.txtLatte.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtLatte.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLatte.Location = New System.Drawing.Point(276, 334)
        Me.txtLatte.Name = "txtLatte"
        Me.txtLatte.Size = New System.Drawing.Size(96, 22)
        Me.txtLatte.TabIndex = 1
        Me.txtLatte.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtEspresso
        '
        Me.txtEspresso.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtEspresso.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEspresso.Location = New System.Drawing.Point(276, 299)
        Me.txtEspresso.Name = "txtEspresso"
        Me.txtEspresso.Size = New System.Drawing.Size(96, 22)
        Me.txtEspresso.TabIndex = 1
        Me.txtEspresso.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtIceLatte
        '
        Me.txtIceLatte.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtIceLatte.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtIceLatte.Location = New System.Drawing.Point(276, 268)
        Me.txtIceLatte.Name = "txtIceLatte"
        Me.txtIceLatte.Size = New System.Drawing.Size(96, 22)
        Me.txtIceLatte.TabIndex = 1
        Me.txtIceLatte.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtCappucino
        '
        Me.txtCappucino.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtCappucino.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCappucino.Location = New System.Drawing.Point(276, 235)
        Me.txtCappucino.Name = "txtCappucino"
        Me.txtCappucino.Size = New System.Drawing.Size(96, 22)
        Me.txtCappucino.TabIndex = 1
        Me.txtCappucino.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtVales
        '
        Me.txtVales.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtVales.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtVales.Location = New System.Drawing.Point(276, 199)
        Me.txtVales.Name = "txtVales"
        Me.txtVales.Size = New System.Drawing.Size(96, 22)
        Me.txtVales.TabIndex = 1
        Me.txtVales.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtAfrican
        '
        Me.txtAfrican.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtAfrican.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAfrican.Location = New System.Drawing.Point(276, 166)
        Me.txtAfrican.Name = "txtAfrican"
        Me.txtAfrican.Size = New System.Drawing.Size(96, 22)
        Me.txtAfrican.TabIndex = 1
        Me.txtAfrican.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtAmerican
        '
        Me.txtAmerican.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtAmerican.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAmerican.Location = New System.Drawing.Point(276, 134)
        Me.txtAmerican.Name = "txtAmerican"
        Me.txtAmerican.Size = New System.Drawing.Size(96, 22)
        Me.txtAmerican.TabIndex = 1
        Me.txtAmerican.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtIced
        '
        Me.txtIced.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtIced.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtIced.Location = New System.Drawing.Point(276, 101)
        Me.txtIced.Name = "txtIced"
        Me.txtIced.Size = New System.Drawing.Size(96, 22)
        Me.txtIced.TabIndex = 1
        Me.txtIced.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chkLatte
        '
        Me.chkLatte.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkLatte.AutoSize = True
        Me.chkLatte.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkLatte.Location = New System.Drawing.Point(14, 333)
        Me.chkLatte.Name = "chkLatte"
        Me.chkLatte.Size = New System.Drawing.Size(70, 24)
        Me.chkLatte.TabIndex = 0
        Me.chkLatte.Text = "Latte"
        Me.chkLatte.UseVisualStyleBackColor = True
        '
        'chkEspresso
        '
        Me.chkEspresso.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkEspresso.AutoSize = True
        Me.chkEspresso.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkEspresso.Location = New System.Drawing.Point(14, 298)
        Me.chkEspresso.Name = "chkEspresso"
        Me.chkEspresso.Size = New System.Drawing.Size(103, 24)
        Me.chkEspresso.TabIndex = 0
        Me.chkEspresso.Text = "Espresso"
        Me.chkEspresso.UseVisualStyleBackColor = True
        '
        'chkIceLatte
        '
        Me.chkIceLatte.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkIceLatte.AutoSize = True
        Me.chkIceLatte.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkIceLatte.Location = New System.Drawing.Point(14, 266)
        Me.chkIceLatte.Name = "chkIceLatte"
        Me.chkIceLatte.Size = New System.Drawing.Size(100, 24)
        Me.chkIceLatte.TabIndex = 0
        Me.chkIceLatte.Text = "Ice Latte"
        Me.chkIceLatte.UseVisualStyleBackColor = True
        '
        'chkCappucino
        '
        Me.chkCappucino.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkCappucino.AutoSize = True
        Me.chkCappucino.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkCappucino.Location = New System.Drawing.Point(14, 231)
        Me.chkCappucino.Name = "chkCappucino"
        Me.chkCappucino.Size = New System.Drawing.Size(113, 24)
        Me.chkCappucino.TabIndex = 0
        Me.chkCappucino.Text = "Cappucino"
        Me.chkCappucino.UseVisualStyleBackColor = True
        '
        'chkVales
        '
        Me.chkVales.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkVales.AutoSize = True
        Me.chkVales.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkVales.Location = New System.Drawing.Point(14, 198)
        Me.chkVales.Name = "chkVales"
        Me.chkVales.Size = New System.Drawing.Size(122, 24)
        Me.chkVales.TabIndex = 0
        Me.chkVales.Text = "Vales Coffe"
        Me.chkVales.UseVisualStyleBackColor = True
        '
        'chkAfrican
        '
        Me.chkAfrican.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkAfrican.AutoSize = True
        Me.chkAfrican.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkAfrican.Location = New System.Drawing.Point(14, 165)
        Me.chkAfrican.Name = "chkAfrican"
        Me.chkAfrican.Size = New System.Drawing.Size(134, 24)
        Me.chkAfrican.TabIndex = 0
        Me.chkAfrican.Text = "African Coffe"
        Me.chkAfrican.UseVisualStyleBackColor = True
        '
        'chkAmerican
        '
        Me.chkAmerican.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkAmerican.AutoSize = True
        Me.chkAmerican.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkAmerican.Location = New System.Drawing.Point(14, 133)
        Me.chkAmerican.Name = "chkAmerican"
        Me.chkAmerican.Size = New System.Drawing.Size(152, 24)
        Me.chkAmerican.TabIndex = 0
        Me.chkAmerican.Text = "American Coffe"
        Me.chkAmerican.UseVisualStyleBackColor = True
        '
        'chkIced
        '
        Me.chkIced.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkIced.AutoSize = True
        Me.chkIced.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkIced.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkIced.Location = New System.Drawing.Point(14, 97)
        Me.chkIced.Name = "chkIced"
        Me.chkIced.Size = New System.Drawing.Size(173, 24)
        Me.chkIced.TabIndex = 0
        Me.chkIced.Text = "Iced - Cappuccino"
        Me.chkIced.UseVisualStyleBackColor = True
        '
        'Panel6
        '
        Me.Panel6.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel6.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel6.Controls.Add(Me.lblTotal)
        Me.Panel6.Controls.Add(Me.lbl1tax)
        Me.Panel6.Controls.Add(Me.lblSubtotal)
        Me.Panel6.Controls.Add(Me.lbl1Subtotal)
        Me.Panel6.Controls.Add(Me.lbltax)
        Me.Panel6.Controls.Add(Me.lbl1Total)
        Me.Panel6.Location = New System.Drawing.Point(511, 521)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(451, 158)
        Me.Panel6.TabIndex = 5
        '
        'lblTotal
        '
        Me.lblTotal.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotal.Location = New System.Drawing.Point(252, 124)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(100, 26)
        Me.lblTotal.TabIndex = 1
        Me.lblTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl1tax
        '
        Me.lbl1tax.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl1tax.AutoSize = True
        Me.lbl1tax.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1tax.Location = New System.Drawing.Point(33, 24)
        Me.lbl1tax.Name = "lbl1tax"
        Me.lbl1tax.Size = New System.Drawing.Size(150, 25)
        Me.lbl1tax.TabIndex = 0
        Me.lbl1tax.Text = "Tax on Order"
        '
        'lblSubtotal
        '
        Me.lblSubtotal.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblSubtotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubtotal.Location = New System.Drawing.Point(252, 78)
        Me.lblSubtotal.Name = "lblSubtotal"
        Me.lblSubtotal.Size = New System.Drawing.Size(100, 26)
        Me.lblSubtotal.TabIndex = 1
        Me.lblSubtotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl1Subtotal
        '
        Me.lbl1Subtotal.AutoSize = True
        Me.lbl1Subtotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1Subtotal.Location = New System.Drawing.Point(33, 72)
        Me.lbl1Subtotal.Name = "lbl1Subtotal"
        Me.lbl1Subtotal.Size = New System.Drawing.Size(113, 25)
        Me.lbl1Subtotal.TabIndex = 0
        Me.lbl1Subtotal.Text = "Sub Total"
        '
        'lbltax
        '
        Me.lbltax.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbltax.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltax.Location = New System.Drawing.Point(252, 30)
        Me.lbltax.Name = "lbltax"
        Me.lbltax.Size = New System.Drawing.Size(100, 26)
        Me.lbltax.TabIndex = 1
        Me.lbltax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl1Total
        '
        Me.lbl1Total.AutoSize = True
        Me.lbl1Total.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1Total.Location = New System.Drawing.Point(33, 120)
        Me.lbl1Total.Name = "lbl1Total"
        Me.lbl1Total.Size = New System.Drawing.Size(65, 25)
        Me.lbl1Total.TabIndex = 0
        Me.lbl1Total.Text = "Total"
        '
        'Panel7
        '
        Me.Panel7.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel7.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel7.Controls.Add(Me.lblService)
        Me.Panel7.Controls.Add(Me.lblCostCake)
        Me.Panel7.Controls.Add(Me.lblCostDrink)
        Me.Panel7.Controls.Add(Me.lbl1Service)
        Me.Panel7.Controls.Add(Me.lbl1CostCake)
        Me.Panel7.Controls.Add(Me.lbl1CostDrink)
        Me.Panel7.Location = New System.Drawing.Point(12, 521)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(493, 158)
        Me.Panel7.TabIndex = 6
        '
        'lblService
        '
        Me.lblService.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblService.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblService.Location = New System.Drawing.Point(230, 118)
        Me.lblService.Name = "lblService"
        Me.lblService.Size = New System.Drawing.Size(100, 26)
        Me.lblService.TabIndex = 1
        Me.lblService.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblCostCake
        '
        Me.lblCostCake.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblCostCake.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCostCake.Location = New System.Drawing.Point(230, 72)
        Me.lblCostCake.Name = "lblCostCake"
        Me.lblCostCake.Size = New System.Drawing.Size(100, 26)
        Me.lblCostCake.TabIndex = 1
        Me.lblCostCake.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblCostDrink
        '
        Me.lblCostDrink.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblCostDrink.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCostDrink.Location = New System.Drawing.Point(230, 24)
        Me.lblCostDrink.Name = "lblCostDrink"
        Me.lblCostDrink.Size = New System.Drawing.Size(100, 26)
        Me.lblCostDrink.TabIndex = 1
        Me.lblCostDrink.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl1Service
        '
        Me.lbl1Service.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl1Service.AutoSize = True
        Me.lbl1Service.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1Service.Location = New System.Drawing.Point(11, 114)
        Me.lbl1Service.Name = "lbl1Service"
        Me.lbl1Service.Size = New System.Drawing.Size(174, 25)
        Me.lbl1Service.TabIndex = 0
        Me.lbl1Service.Text = "Service Charge"
        '
        'lbl1CostCake
        '
        Me.lbl1CostCake.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl1CostCake.AutoSize = True
        Me.lbl1CostCake.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1CostCake.Location = New System.Drawing.Point(11, 66)
        Me.lbl1CostCake.Name = "lbl1CostCake"
        Me.lbl1CostCake.Size = New System.Drawing.Size(160, 25)
        Me.lbl1CostCake.TabIndex = 0
        Me.lbl1CostCake.Text = "Cost of Cakes"
        '
        'lbl1CostDrink
        '
        Me.lbl1CostDrink.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl1CostDrink.AutoSize = True
        Me.lbl1CostDrink.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1CostDrink.Location = New System.Drawing.Point(11, 18)
        Me.lbl1CostDrink.Name = "lbl1CostDrink"
        Me.lbl1CostDrink.Size = New System.Drawing.Size(161, 25)
        Me.lbl1CostDrink.TabIndex = 0
        Me.lbl1CostDrink.Text = "Cost of Drinks"
        '
        'Timer1
        '
        '
        'PrintDialog1
        '
        Me.PrintDialog1.UseEXDialog = True
        '
        'PrintDocument1
        '
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'Label1
        '
        Me.Label1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(309, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(814, 73)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Cafe Management System"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(-387, 88)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(39, 13)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Label1"
        '
        'lblDate
        '
        Me.lblDate.AutoSize = True
        Me.lblDate.Font = New System.Drawing.Font("Segoe Print", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDate.ForeColor = System.Drawing.Color.Red
        Me.lblDate.Location = New System.Drawing.Point(1129, 72)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(65, 28)
        Me.lblDate.TabIndex = 1
        Me.lblDate.Text = "Label5"
        '
        'lblTime
        '
        Me.lblTime.AutoSize = True
        Me.lblTime.Font = New System.Drawing.Font("Segoe Print", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTime.ForeColor = System.Drawing.Color.Red
        Me.lblTime.Location = New System.Drawing.Point(26, 72)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(65, 28)
        Me.lblTime.TabIndex = 1
        Me.lblTime.Text = "Label5"
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Controls.Add(Me.lblTime)
        Me.Panel1.Controls.Add(Me.lblDate)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(12, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1328, 111)
        Me.Panel1.TabIndex = 0
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'ImageList1
        '
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'ImageList2
        '
        Me.ImageList2.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList2.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList2.TransparentColor = System.Drawing.Color.Transparent
        '
        'ToolStripButton3
        '
        Me.ToolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton3.Image = Global.CafeManagementSystem.My.Resources.Resources.document1600
        Me.ToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton3.Name = "ToolStripButton3"
        Me.ToolStripButton3.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton3.Text = "New File"
        '
        'ToolStripButton2
        '
        Me.ToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton2.Image = Global.CafeManagementSystem.My.Resources.Resources.open_folder16001
        Me.ToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton2.Name = "ToolStripButton2"
        Me.ToolStripButton2.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton2.Text = "Open File"
        '
        'saveToolStripButton1
        '
        Me.saveToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.saveToolStripButton1.Image = Global.CafeManagementSystem.My.Resources.Resources.save1600
        Me.saveToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.saveToolStripButton1.Name = "saveToolStripButton1"
        Me.saveToolStripButton1.Size = New System.Drawing.Size(23, 22)
        Me.saveToolStripButton1.Text = "Save"
        '
        'printToolStripButton2
        '
        Me.printToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.printToolStripButton2.Image = Global.CafeManagementSystem.My.Resources.Resources.print1600
        Me.printToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.printToolStripButton2.Name = "printToolStripButton2"
        Me.printToolStripButton2.Size = New System.Drawing.Size(23, 22)
        Me.printToolStripButton2.Text = "Print"
        '
        'cutToolStripButton1
        '
        Me.cutToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.cutToolStripButton1.Image = Global.CafeManagementSystem.My.Resources.Resources.Cut_icon
        Me.cutToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cutToolStripButton1.Name = "cutToolStripButton1"
        Me.cutToolStripButton1.Size = New System.Drawing.Size(23, 22)
        Me.cutToolStripButton1.Text = "Cut"
        '
        'copyToolStripButton1
        '
        Me.copyToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.copyToolStripButton1.Image = Global.CafeManagementSystem.My.Resources.Resources.copy1600
        Me.copyToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.copyToolStripButton1.Name = "copyToolStripButton1"
        Me.copyToolStripButton1.Size = New System.Drawing.Size(23, 22)
        Me.copyToolStripButton1.Text = "Copy"
        Me.copyToolStripButton1.ToolTipText = "copyToolStripButton1"
        '
        'pasteToolStripButton
        '
        Me.pasteToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.pasteToolStripButton.Image = Global.CafeManagementSystem.My.Resources.Resources.paste_clipart_pngmedium_paste_icon_button_10271
        Me.pasteToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.pasteToolStripButton.Name = "pasteToolStripButton"
        Me.pasteToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.pasteToolStripButton.Text = "Paste"
        '
        'helpToolStripButton1
        '
        Me.helpToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.helpToolStripButton1.Image = Global.CafeManagementSystem.My.Resources.Resources.help1600
        Me.helpToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.helpToolStripButton1.Name = "helpToolStripButton1"
        Me.helpToolStripButton1.Size = New System.Drawing.Size(23, 22)
        Me.helpToolStripButton1.Text = "Help"
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.Image = Global.CafeManagementSystem.My.Resources.Resources.cafe1600
        Me.PictureBox1.Location = New System.Drawing.Point(167, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(129, 101)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 7
        Me.PictureBox1.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(1352, 691)
        Me.Controls.Add(Me.Panel7)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents txtQueen As TextBox
    Friend WithEvents txtCoffeCake As TextBox
    Friend WithEvents chkQueen As CheckBox
    Friend WithEvents txtRed As TextBox
    Friend WithEvents chkCarlton As CheckBox
    Friend WithEvents txtBlackForest As TextBox
    Friend WithEvents chkKilburn As CheckBox
    Friend WithEvents txtBostom As TextBox
    Friend WithEvents chkLagos As CheckBox
    Friend WithEvents txtLagos As TextBox
    Friend WithEvents chkBostom As CheckBox
    Friend WithEvents txtKilburn As TextBox
    Friend WithEvents chkBlackForest As CheckBox
    Friend WithEvents txtCharlton As TextBox
    Friend WithEvents chkRed As CheckBox
    Friend WithEvents chkCoffeCake As CheckBox
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents btnReceipt As Button
    Friend WithEvents TotalButton As Button
    Friend WithEvents txtLatte As TextBox
    Friend WithEvents txtEspresso As TextBox
    Friend WithEvents txtIceLatte As TextBox
    Friend WithEvents txtCappucino As TextBox
    Friend WithEvents txtVales As TextBox
    Friend WithEvents txtAfrican As TextBox
    Friend WithEvents txtAmerican As TextBox
    Friend WithEvents txtIced As TextBox
    Friend WithEvents chkLatte As CheckBox
    Friend WithEvents chkEspresso As CheckBox
    Friend WithEvents chkIceLatte As CheckBox
    Friend WithEvents chkCappucino As CheckBox
    Friend WithEvents chkVales As CheckBox
    Friend WithEvents chkAfrican As CheckBox
    Friend WithEvents chkAmerican As CheckBox
    Friend WithEvents chkIced As CheckBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lbl1Service As Label
    Friend WithEvents lbl1CostCake As Label
    Friend WithEvents lbl1CostDrink As Label
    Friend WithEvents lblTotal As TextBox
    Friend WithEvents lbl1tax As Label
    Friend WithEvents lblSubtotal As TextBox
    Friend WithEvents lbl1Subtotal As Label
    Friend WithEvents lbltax As TextBox
    Friend WithEvents lbl1Total As Label
    Friend WithEvents lblService As TextBox
    Friend WithEvents lblCostCake As TextBox
    Friend WithEvents lblCostDrink As TextBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents rtfReceipt As RichTextBox
    Friend WithEvents ToolStripButton1 As ToolStripButton
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents pasteToolStripButton As ToolStripButton
    Friend WithEvents printToolStripButton2 As ToolStripButton
    Friend WithEvents copyToolStripButton1 As ToolStripButton
    Friend WithEvents cutToolStripButton1 As ToolStripButton
    Friend WithEvents helpToolStripButton1 As ToolStripButton
    Friend WithEvents saveToolStripButton1 As ToolStripButton
    Friend WithEvents newToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents ToolStripButton2 As ToolStripButton
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents PrintDialog1 As PrintDialog
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents PrintPreviewDialog1 As PrintPreviewDialog
    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblDate As Label
    Friend WithEvents lblTime As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents ToolStripButton3 As ToolStripButton
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents ImageList1 As ImageList
    Friend WithEvents ImageList2 As ImageList
    Friend WithEvents PictureBox1 As PictureBox
End Class
