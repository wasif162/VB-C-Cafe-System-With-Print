﻿Public Class Form1


    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
    Application.Exit()

End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        lblDate.Text = DateTime.Now.ToLongDateString
        Timer1.Start()

        txtAfrican.Text = "0"
        txtAmerican.Text = "0"
        txtCappucino.Text = "0"
        txtEspresso.Text = "0"
        txtIced.Text = "0"
        txtIceLatte.Text = "0"
        txtVales.Text = "0"
        txtBlackForest.Text = "0"
        txtBostom.Text = "0"
        txtCharlton.Text = "0"
        txtCoffeCake.Text = "0"
        txtLatte.Text = "0"
        txtKilburn.Text = "0"
        txtLagos.Text = "0"
        txtQueen.Text = "0"
        txtRed.Text = "0"
        txtVales.Text = "0"
        lblCostDrink.Text = "0"
        lblCostCake.Text = "0"
        lblService.Text = "0" 'it's up to you


        txtAfrican.Enabled = False
        txtAmerican.Enabled = False
        txtBlackForest.Enabled = False
        txtBostom.Enabled = False
        txtCappucino.Enabled = False
        txtCharlton.Enabled = False
        txtCoffeCake.Enabled = False
        txtEspresso.Enabled = False
        txtIced.Enabled = False
        txtIceLatte.Enabled = False
        txtKilburn.Enabled = False
        txtLagos.Enabled = False
        txtLatte.Enabled = False
        txtQueen.Enabled = False
        txtRed.Enabled = False
        txtVales.Enabled = False

        rtfReceipt.Clear()

        chkAfrican.Checked = False
        chkAmerican.Checked = False
        chkBlackForest.Checked = False
        chkBostom.Checked = False
        chkCappucino.Checked = False
        chkCarlton.Checked = False
        chkCoffeCake.Checked = False
        chkEspresso.Checked = False
        chkIced.Checked = False
        chkIceLatte.Checked = False
        chkKilburn.Checked = False
        chkLagos.Checked = False
        chkLatte.Checked = False
        chkQueen.Checked = False
        chkRed.Checked = False
        chkVales.Checked = False


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        lblSubtotal.Text = "0"
        lbltax.Text = "0"
        lblTotal.Text = "0"

        txtAfrican.Text = "0"
        txtAmerican.Text = "0"
        txtCappucino.Text = "0"
        txtEspresso.Text = "0"
        txtIced.Text = "0"
        txtIceLatte.Text = "0"
        txtVales.Text = "0"
        txtBlackForest.Text = "0"
        txtBostom.Text = "0"
        txtCharlton.Text = "0"
        txtCoffeCake.Text = "0"
        txtLatte.Text = "0"
        txtKilburn.Text = "0"
        txtLagos.Text = "0"
        txtQueen.Text = "0"
        txtRed.Text = "0"
        txtVales.Text = "0"
        lblCostDrink.Text = "0"
        lblCostCake.Text = "0"
        lblService.Text = "0" 'it's up to you


        txtAfrican.Enabled = False
        txtAmerican.Enabled = False
        txtBlackForest.Enabled = False
        txtBostom.Enabled = False
        txtCappucino.Enabled = False
        txtCharlton.Enabled = False
        txtCoffeCake.Enabled = False
        txtEspresso.Enabled = False
        txtIced.Enabled = False
        txtIceLatte.Enabled = False
        txtKilburn.Enabled = False
        txtLagos.Enabled = False
        txtLatte.Enabled = False
        txtQueen.Enabled = False
        txtRed.Enabled = False
        txtVales.Enabled = False

        rtfReceipt.Clear()

        chkAfrican.Checked = False
        chkAmerican.Checked = False
        chkBlackForest.Checked = False
        chkBostom.Checked = False
        chkCappucino.Checked = False
        chkCarlton.Checked = False
        chkCoffeCake.Checked = False
        chkEspresso.Checked = False
        chkIced.Checked = False
        chkIceLatte.Checked = False
        chkKilburn.Checked = False
        chkLagos.Checked = False
        chkLatte.Checked = False
        chkQueen.Checked = False
        chkRed.Checked = False
        chkVales.Checked = False
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        lblTime.Text = DateTime.Now.ToLongTimeString
    End Sub

    Private Sub btnReceipt_Click(sender As Object, e As EventArgs) Handles btnReceipt.Click
        rtfReceipt.Clear()

        rtfReceipt.AppendText(vbTab + vbTab + vbTab + "Just Do Coffe" + Environment.NewLine)
        rtfReceipt.AppendText(vbTab + "---------------------------------------------------------------------------" + Environment.NewLine)

        rtfReceipt.AppendText(vbTab + "Queen's Park Chocolate Cake" + vbTab + vbTab + txtQueen.Text + Environment.NewLine)
        rtfReceipt.AppendText(vbTab + "Carlton Hill Chocolate Cake" + vbTab + vbTab + txtCharlton.Text + Environment.NewLine)
        rtfReceipt.AppendText(vbTab + "Killburn Chocolate Cake" + vbTab + vbTab + vbTab + txtKilburn.Text + Environment.NewLine)
        rtfReceipt.AppendText(vbTab + "Lagos Chocolate Cake" + vbTab + vbTab + vbTab + txtLagos.Text + Environment.NewLine)
        rtfReceipt.AppendText(vbTab + "Bostom Cream Cake" + vbTab + vbTab + vbTab + txtBostom.Text + Environment.NewLine)
        rtfReceipt.AppendText(vbTab + "Black Forest Cake" + vbTab + vbTab + vbTab + txtBlackForest.Text + Environment.NewLine)
        rtfReceipt.AppendText(vbTab + "Red Velvet Cake" + vbTab + vbTab + vbTab + vbTab + txtRed.Text + Environment.NewLine)
        rtfReceipt.AppendText(vbTab + "Coffe Cake" + vbTab + vbTab + vbTab + vbTab + txtCoffeCake.Text + Environment.NewLine)

        rtfReceipt.AppendText(vbTab + "Iced Cappucino" + vbTab + vbTab + vbTab + vbTab + txtIced.Text + Environment.NewLine)
        rtfReceipt.AppendText(vbTab + "American Coffe" + vbTab + vbTab + vbTab + vbTab + txtAmerican.Text + Environment.NewLine)
        rtfReceipt.AppendText(vbTab + "African Coffe" + vbTab + vbTab + vbTab + vbTab + txtAfrican.Text + Environment.NewLine)
        rtfReceipt.AppendText(vbTab + "Cappucino" + vbTab + vbTab + vbTab + vbTab + txtCappucino.Text + Environment.NewLine)
        rtfReceipt.AppendText(vbTab + "Vale Coffe" + vbTab + vbTab + vbTab + vbTab + txtVales.Text + Environment.NewLine)
        rtfReceipt.AppendText(vbTab + "Iced Latte" + vbTab + vbTab + vbTab + vbTab + txtIceLatte.Text + Environment.NewLine)
        rtfReceipt.AppendText(vbTab + "Espresso" + vbTab + vbTab + vbTab + vbTab + txtEspresso.Text + Environment.NewLine)
        rtfReceipt.AppendText(vbTab + "Latte" + vbTab + vbTab + vbTab + vbTab + vbTab + txtLatte.Text + Environment.NewLine)

        rtfReceipt.AppendText(vbTab + "-----------------------------------------------------------------------------" + Environment.NewLine)
        rtfReceipt.AppendText(vbTab + "Service Charge" + vbTab + vbTab + vbTab + vbTab + lblService.Text + Environment.NewLine)
        rtfReceipt.AppendText(vbTab + "-----------------------------------------------------------------------------" + Environment.NewLine)
        rtfReceipt.AppendText(vbTab + "Tax" + vbTab + vbTab + vbTab + vbTab + vbTab + lbltax.Text + Environment.NewLine)
        rtfReceipt.AppendText(vbTab + "Sub Total" + vbTab + vbTab + vbTab + vbTab + lblSubtotal.Text + Environment.NewLine)
        rtfReceipt.AppendText(vbTab + "Total Cost" + vbTab + vbTab + vbTab + vbTab + lblTotal.Text + Environment.NewLine)
        rtfReceipt.AppendText(vbTab + "-----------------------------------------------------------------------------" + Environment.NewLine)
        rtfReceipt.AppendText(vbTab + lblTime.Text + vbTab + vbTab + vbTab + lblDate.Text)
    End Sub

    Private Sub chkIced_CheckedChanged(sender As Object, e As EventArgs) Handles chkIced.CheckedChanged
        If (chkIced.Checked = True) Then
            txtIced.Enabled = True
        End If

        If (chkIced.Checked = False) Then
            txtIced.Enabled = False
        End If
    End Sub

    Private Sub txtIced_Click(sender As Object, e As EventArgs) Handles txtIced.Click
        txtIced.Text = ""
        txtIced.Focus()
    End Sub

    Private Sub chkAmerican_CheckedChanged(sender As Object, e As EventArgs) Handles chkAmerican.CheckedChanged
        If (chkAmerican.Checked = True) Then
            txtAmerican.Enabled = True
        End If

        If (chkAmerican.Checked = False) Then
            txtAmerican.Enabled = False
        End If
    End Sub

    Private Sub txtAmerican_Click(sender As Object, e As EventArgs) Handles txtAmerican.Click
        txtAmerican.Text = ""
        txtAmerican.Focus()
    End Sub

    Private Sub chkAfrican_CheckedChanged(sender As Object, e As EventArgs) Handles chkAfrican.CheckedChanged
        If (chkAfrican.Checked = True) Then
            txtAfrican.Enabled = True
        End If

        If (chkAfrican.Checked = False) Then
            txtAfrican.Enabled = False
        End If
    End Sub

    Private Sub txtAfrican_Click(sender As Object, e As EventArgs) Handles txtAfrican.Click
        txtAfrican.Text = ""
        txtAfrican.Focus()
    End Sub

    Private Sub chkVales_CheckedChanged(sender As Object, e As EventArgs) Handles chkVales.CheckedChanged
        If (chkVales.Checked = True) Then
            txtVales.Enabled = True
        End If

        If (chkVales.Checked = False) Then
            txtVales.Enabled = False
        End If
    End Sub

    Private Sub txtVales_Click(sender As Object, e As EventArgs) Handles txtVales.Click
        txtVales.Text = ""
        txtVales.Focus()
    End Sub

    Private Sub chkCappucino_CheckedChanged(sender As Object, e As EventArgs) Handles chkCappucino.CheckedChanged
        If (chkCappucino.Checked = True) Then
            txtCappucino.Enabled = True
        End If

        If (chkCappucino.Checked = False) Then
            txtCappucino.Enabled = False
        End If
    End Sub

    Private Sub txtCappucino_Click(sender As Object, e As EventArgs) Handles txtCappucino.Click
        txtCappucino.Text = ""
        txtCappucino.Focus()
    End Sub

    Private Sub chkIceLatte_CheckedChanged(sender As Object, e As EventArgs) Handles chkIceLatte.CheckedChanged
        If (chkIceLatte.Checked = True) Then
            txtIceLatte.Enabled = True
        End If

        If (chkIceLatte.Checked = False) Then
            txtIceLatte.Enabled = False
        End If
    End Sub

    Private Sub txtIceLatte_Click(sender As Object, e As EventArgs) Handles txtIceLatte.Click
        txtIceLatte.Text = ""
        txtIceLatte.Focus()
    End Sub

    Private Sub chkEspresso_CheckedChanged(sender As Object, e As EventArgs) Handles chkEspresso.CheckedChanged
        If (chkEspresso.Checked = True) Then
            txtEspresso.Enabled = True
        End If

        If (chkEspresso.Checked = False) Then
            txtEspresso.Enabled = False
        End If
    End Sub

    Private Sub txtEspresso_Click(sender As Object, e As EventArgs) Handles txtEspresso.Click
        txtEspresso.Text = ""
        txtEspresso.Focus()
    End Sub

    Private Sub chkLatte_CheckedChanged(sender As Object, e As EventArgs) Handles chkLatte.CheckedChanged
        If (chkLatte.Checked = True) Then
            txtLatte.Enabled = True
        End If

        If (chkLatte.Checked = False) Then
            txtLatte.Enabled = False
        End If
    End Sub

    Private Sub txtLatte_Click(sender As Object, e As EventArgs) Handles txtLatte.Click
        txtLatte.Text = ""
        txtLatte.Focus()
    End Sub

    Private Sub chkQueen_CheckedChanged(sender As Object, e As EventArgs) Handles chkQueen.CheckedChanged
        If (chkQueen.Checked = True) Then
            txtQueen.Enabled = True
        End If

        If (chkQueen.Checked = False) Then
            txtQueen.Enabled = False
        End If
    End Sub

    Private Sub txtQueen_Click(sender As Object, e As EventArgs) Handles txtQueen.Click
        txtQueen.Text = ""
        txtQueen.Focus()
    End Sub

    Private Sub chkCarlton_CheckedChanged(sender As Object, e As EventArgs) Handles chkCarlton.CheckedChanged
        If (chkCarlton.Checked = True) Then
            txtCharlton.Enabled = True
        End If

        If (chkCarlton.Checked = False) Then
            txtCharlton.Enabled = False
        End If
    End Sub

    Private Sub txtCharlton_Click(sender As Object, e As EventArgs) Handles txtCharlton.Click
        txtCharlton.Text = ""
        txtCharlton.Focus()
    End Sub

    Private Sub chkKilburn_CheckedChanged(sender As Object, e As EventArgs) Handles chkKilburn.CheckedChanged
        If (chkKilburn.Checked = True) Then
            txtKilburn.Enabled = True
        End If

        If (chkKilburn.Checked = False) Then
            txtKilburn.Enabled = False
        End If
    End Sub

    Private Sub txtKilburn_Click(sender As Object, e As EventArgs) Handles txtKilburn.Click
        txtKilburn.Text = ""
        txtKilburn.Focus()
    End Sub

    Private Sub chkLagos_CheckedChanged(sender As Object, e As EventArgs) Handles chkLagos.CheckedChanged
        If (chkLagos.Checked = True) Then
            txtLatte.Enabled = True
        End If

        If (chkLagos.Checked = False) Then
            txtLagos.Enabled = False
        End If
    End Sub

    Private Sub txtLagos_Click(sender As Object, e As EventArgs) Handles txtLagos.Click
        txtLagos.Text = ""
        txtKilburn.Focus()
    End Sub

    Private Sub chkBostom_CheckedChanged(sender As Object, e As EventArgs) Handles chkBostom.CheckedChanged
        If (chkBostom.Checked = True) Then
            txtBostom.Enabled = True
        End If

        If (chkBostom.Checked = False) Then
            txtBostom.Enabled = False
        End If
    End Sub

    Private Sub txtBostom_Click(sender As Object, e As EventArgs) Handles txtBostom.Click
        txtBostom.Text = ""
        txtBostom.Focus()
    End Sub

    Private Sub chkBlackForest_CheckedChanged(sender As Object, e As EventArgs) Handles chkBlackForest.CheckedChanged
        If (chkBlackForest.Checked = True) Then
            txtBlackForest.Enabled = True
        End If

        If (chkBlackForest.Checked = False) Then
            txtBlackForest.Enabled = False
        End If
    End Sub

    Private Sub txtBlackForest_Click(sender As Object, e As EventArgs) Handles txtBlackForest.Click
        txtBlackForest.Text = ""
        txtBlackForest.Focus()
    End Sub

    Private Sub chkRed_CheckedChanged(sender As Object, e As EventArgs) Handles chkRed.CheckedChanged
        If (chkRed.Checked = True) Then
            txtRed.Enabled = True
        End If

        If (chkRed.Checked = False) Then
            txtRed.Enabled = False
        End If
    End Sub

    Private Sub txtRed_Click(sender As Object, e As EventArgs) Handles txtRed.Click
        txtRed.Text = ""
        txtRed.Focus()
    End Sub

    Private Sub chkCoffeCake_CheckedChanged(sender As Object, e As EventArgs) Handles chkCoffeCake.CheckedChanged
        If (chkCoffeCake.Checked = True) Then
            txtCoffeCake.Enabled = True
        End If

        If (chkCoffeCake.Checked = False) Then
            txtCoffeCake.Enabled = False
        End If
    End Sub

    Private Sub txtCoffeCake_Click(sender As Object, e As EventArgs) Handles txtCoffeCake.Click
        txtCoffeCake.Text = ""
        txtCoffeCake.Focus()
    End Sub

    Private Sub txtNumbersOnly(sender As Object, e As KeyPressEventArgs) Handles txtVales.KeyPress, txtRed.KeyPress, txtQueen.KeyPress, txtLatte.KeyPress, txtLagos.KeyPress, txtKilburn.KeyPress, txtIceLatte.KeyPress, txtIced.KeyPress, txtEspresso.KeyPress, txtCoffeCake.KeyPress, txtCharlton.KeyPress, txtCappucino.KeyPress, txtBostom.KeyPress, txtBlackForest.KeyPress, txtAmerican.KeyPress, txtAfrican.KeyPress

        If Char.IsDigit(e.KeyChar) = False And Char.IsControl(e.KeyChar) = False Then
            e.Handled = True
            MsgBox("Please enter valid number", MsgBoxStyle.Information)
        End If
    End Sub

    Private Sub pasteToolStripButton_Click(sender As Object, e As EventArgs) Handles pasteToolStripButton.Click
        rtfReceipt.Paste()
    End Sub

    Private Sub copyToolStripButton1_Click(sender As Object, e As EventArgs) Handles copyToolStripButton1.Click
        rtfReceipt.Copy()
    End Sub
    Private Sub cutToolStripButton1_Click(sender As Object, e As EventArgs) Handles cutToolStripButton1.Click
        rtfReceipt.Cut()
    End Sub

    Private Sub printToolStripButton2_Click(sender As Object, e As EventArgs) Handles printToolStripButton2.Click
        PrintPreviewDialog1.Document = PrintDocument1
        PrintPreviewDialog1.ShowDialog()
    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        e.Graphics.DrawString(rtfReceipt.Text, New Font("Arial", 14, FontStyle.Regular), Brushes.Black, 120, 120)
    End Sub

    Private Sub ToolStripButton3_Click(sender As Object, e As EventArgs) Handles ToolStripButton3.Click
        rtfReceipt.Clear()
    End Sub

    Private Sub ToolStripButton2_Click(sender As Object, e As EventArgs) Handles ToolStripButton2.Click
        ' This code will Open Text Files
        OpenFileDialog1.Filter = "Text Files (*.txt)|*.txt|All files(*.*)|*.*"
        If (OpenFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK) Then
            rtfReceipt.LoadFile(OpenFileDialog1.FileName, RichTextBoxStreamType.PlainText)
        End If
    End Sub

    Private Sub saveToolStripButton1_Click(sender As Object, e As EventArgs) Handles saveToolStripButton1.Click
        SaveFileDialog1.Filter = "TXT Files (*.txt)|*.txt"
#Disable Warning BC30456 ' 'Forms' is not a member of 'Windows'.
        If SaveFileDialog1.ShowDialog = System.Windows.Forms.DialogResult.OK Then
#Enable Warning BC30456 ' 'Forms' is not a member of 'Windows'.
            My.Computer.FileSystem.WriteAllText(SaveFileDialog1.FileName, rtfReceipt.Text, True)
        End If
    End Sub

    Private Sub helpToolStripButton1_Click(sender As Object, e As EventArgs) Handles helpToolStripButton1.Click
#Disable Warning BC30203 ' Identifier expected.
        AboutBox1.Show()
#Enable Warning BC30203 ' Identifier expected.
    End Sub

    Private Sub TotalButton_Click(sender As Object, e As EventArgs) Handles TotalButton.Click
        Dim tax As Double
        tax = 0
        Dim latte, espres, ilatte, vale, aCoff, amCoff, capp, iCapp As Double
        Dim cCake, rVel, bFor, cBos, cKilb, cCarl, cCqueen, cLag As Double
        ' coffe
        latte = 20000
        espres = 25000
        ilatte = 25000
        vale = 24000
        aCoff = 25000
        capp = 27000
        iCapp = 15000
        Dim latte_Coff As Double = Convert.ToDouble(txtLatte.Text)
        Dim espresson As Double = Convert.ToDouble(txtEspresso.Text)
        Dim IcedLatte As Double = Convert.ToDouble(txtIceLatte.Text)
        Dim vale_Coff As Double = Convert.ToDouble(txtVales.Text)
        Dim Afri_Coff As Double = Convert.ToDouble(txtAfrican.Text)
        Dim Amer_Coff As Double = Convert.ToDouble(txtAmerican.Text)
        Dim Capp_Coff As Double = Convert.ToDouble(txtCappucino.Text)
        Dim iCapp_Coff As Double = Convert.ToDouble(txtIced.Text)

        'Cake
        cCake = 13000
        rVel = 12000
        bFor = 13000
        cBos = 20000
        cLag = 25000
        cKilb = 24000
        cCarl = 23000
        cCqueen = 12000

        Dim c_Cakes As Double = Convert.ToDouble(txtCoffeCake.Text)
        Dim vl_Cakes As Double = Convert.ToDouble(txtRed.Text)
        Dim bF_Cakes As Double = Convert.ToDouble(txtBlackForest.Text)
        Dim cB_Cakes As Double = Convert.ToDouble(txtBostom.Text)
        Dim cL_Cakes As Double = Convert.ToDouble(txtLagos.Text)
        Dim cK_Cakes As Double = Convert.ToDouble(txtKilburn.Text)
        Dim cC_Cakes As Double = Convert.ToDouble(txtCharlton.Text)
        Dim cQ_Cakes As Double = Convert.ToDouble(txtQueen.Text)
        '===================================================================
        Dim cost_of_drinks, service_charge, cost_of_cakes, iTax As Double
        cost_of_drinks = (latte_Coff * latte) + (espresson * espres) + (IcedLatte * ilatte) _
            + (vale * vale_Coff) + (aCoff * Afri_Coff) + (amCoff * Amer_Coff) _
            + (capp * Capp_Coff) + (iCapp * iCapp_Coff)
        lblCostDrink.Text = Convert.ToString(cost_of_drinks)
        cost_of_cakes = (cCake * c_Cakes) + (rVel * vl_Cakes) + (bFor * bF_Cakes) _
            + (cBos * cB_Cakes) + (cLag * cL_Cakes) + (cKilb * cK_Cakes) _
            + (cCarl * cC_Cakes) + (cCqueen * cQ_Cakes)
        lblCostCake.Text = Convert.ToString(cost_of_cakes)

        service_charge = Convert.ToDouble(lblService.Text)

        lblSubtotal.Text = Convert.ToString(cost_of_cakes + service_charge)
        lbltax.Text = Convert.ToString(((cost_of_cakes + cost_of_drinks + service_charge) * tax) / 100)
        iTax = Convert.ToDouble(lbltax.Text)
        lblTotal.Text = Convert.ToString(cost_of_cakes + cost_of_drinks + iTax + service_charge)

        lblCostCake.Text = FormatCurrency(cost_of_cakes)
        lblCostDrink.Text = FormatCurrency(cost_of_drinks)
        lblService.Text = FormatCurrency(service_charge)
        lblSubtotal.Text = FormatCurrency((cost_of_cakes + cost_of_drinks + service_charge))
        lbltax.Text = FormatCurrency(iTax)
        lblTotal.Text = FormatCurrency((cost_of_cakes + cost_of_drinks + service_charge + iTax))

    End Sub
End Class